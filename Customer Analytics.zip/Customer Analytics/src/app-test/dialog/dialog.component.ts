import { Component} from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
//import{AppComponent} from '../app.component';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.sass']
 // providers: [AppComponent]

})
export class DialogComponent {
  Available = "";
  Popflag = "";
  pop = "";
  Notes="";
  constructor(public dialog: MatDialog) {
    //console.log(this.app.popupFlag);
      this.pop = window.localStorage.getItem("pop");
      console.log(this.pop);
  }
    save()
    {
       console.log(this.Available);
    }  

    cancel()
    {
       this.Available = '';
    }  
  openDial(){
  this.dialog.open(DialogComponent);      
    }
  }