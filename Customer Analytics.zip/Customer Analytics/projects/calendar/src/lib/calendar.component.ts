import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-calendar',
  template: `
    <p>
      calendar works!
    </p>
  `,
  styles: [
  ],
})
export class CalendarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
