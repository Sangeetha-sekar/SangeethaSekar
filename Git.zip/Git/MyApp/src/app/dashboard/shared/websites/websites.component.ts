import { Component } from "@angular/core";

@Component({
    selector: 'websites-home',
    template: '<div test-directive>Website</div><button routerLink="">Home</button>',
})
export class WebsitesHome {
}