import { Component } from "@angular/core";

@Component({
    selector: 'dashboard-home',
    template: '<div test-directive>Dashboard</div><button routerLink="">Home</button>',
})
export class DashboardHome {
}