import { Component, Input, Output,EventEmitter,OnInit, OnDestroy,OnChanges, DoCheck,
   AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked} from '@angular/core';

@Component({
  selector: 'hello',
  template: `<p>Hello {{names}}! <button (click)="sendDataToParent()">Click</button></p>`,
  styles: [`p { font-family: Lato; }`]
})
export class HelloComponent implements OnInit, OnDestroy, OnChanges, DoCheck, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked {
  @Input('aliasName') names: string;
  @Output() sendData:EventEmitter<any>=new EventEmitter<any>();
  
  constructor(){

  }
   ngOnChanges(){
     console.log("Onchanges");
   }
  ngOnInit(){
    console.log("Component Initialized");
    setTimeout(()=>{
      console.log(new Date());
},1000)
  }

  ngDoCheck(){
    console.log("DoCheck");
  }
   
  ngAfterViewInit(){
    console.log("AfterViewInit");
  }

  ngAfterViewChecked(){
console.log("AfterViewChecked");
  }

  ngAfterContentInit(){
    console.log("AfterContentInit");
  }

  ngAfterContentChecked(){
    console.log("AfterContentChecked");
  }
  ngOnDestroy(){
    console.log("Component Destroyed");
  }
  sendDataToParent(){
    this.sendData.emit("Sending the Transfer");
  }
}
