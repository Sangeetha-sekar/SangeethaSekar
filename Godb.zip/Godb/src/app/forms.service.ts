import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class FormsService {
    // Variable Declaration Part
    public loginMemberDetails = [
        { 'Email': 'sangysekar@gmail.com', 'Password': 'password' },
        { 'Email': 'keerthi@gmail.com', 'Password': 'keerthi' },
        { 'Email': 'sekar@gmail.com', 'Password': 'sekar' },
        { 'Email': 'kavitha@gmail.com', 'Password': 'kavitha' }
    ];
    public form_fulldetails: any = [{'firstName': '','lastName': '','emailid': '','password': '','confirmpassword': '',
        'phone': '','myRadio': '','address': '','emailFlag': '','mobNumberPattern': ''}]; 
    
    constructor() { }
}

